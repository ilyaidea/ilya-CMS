function edit_form(e, actions, index, edit_actions, codeplayer, player) {
    $("#codeplayer_edit_form").remove();
    if (edit_actions === []) {
        return;
    }

    // console.log(codeplayer.editor.getSelections());
    console.log(edit_actions);
    // alert(len(edit_actions));
    var codeplayer_edit_form = $('<div id="codeplayer_edit_form" class="row"></div>');

    for (var i in edit_actions) {
        var index = edit_actions[i].index;
        var col = $('<div class="col-sm-4"></div>');
        var child = $('<form action="test.php?index=' + index + '"></form>');
        var label = $('<lable>' + edit_actions[i].type + '</lable>');
        var type = edit_actions[i].type;

        for (var option in edit_actions[i].options) {
            var input = '';
            var label2 = $('<label>' + option + ' : </label>');
            var error = $('<label style="color: #e74c3c;" class="error" for="name" id="name_error"></label>');

            var val = edit_actions[i].options[option];
            if (option === 'step' || option === 'locale') {

                input = text_input(option, val);
            }
            else if (option === 'text' || option === 'text2' || option === 'location') {
                input = textarea_input(option, val);
            }
            else if (option === 'attachment') {
                var arr_options = {
                    "element": "element",
                    "selection": "selection"
                };
                input = select_options_input(arr_options, option, val);
            }
            else if (option === 'success' || option === 'add' || option === 'hideOthers') {
                var bool_options = {
                    "true": "true",
                    "false": "false"
                };
                input = select_options_input(bool_options, option, val);
            }
            else if (option === 'place') {
                var bool_options = {
                    "text": "text",
                    "type": "type",
                    "end": "end"
                };
                input = select_options_input(bool_options, option, val);
            }
            else if (option === 'placement') {
                var bool_options = {
                    "right": "right",
                    "left": "left",
                    "bottom": "bottom",
                    "top": "top"
                };
                input = select_options_input(bool_options, option, val);
            }
            else if (option === 'hide') {
                var bool_options = {
                    "none": "none",
                };
                input = select_options_input(bool_options, option, val);
            }
            else if (option === 'timeout') {
                input = text_input(option, val);
            }
            else if (option === 'command' || option === 'selector') {
                input = text_input(option, val);
            }
            else if (option === 'delay' || option === 'beforeDelay') {
                input = text_input(option, val);
            }

            child.append(label2);
            child.append(input);
            child.append(error);
            child.append('<br>');
        }

        child.append('<input type="hidden" name="type" value="' + edit_actions[i].type + '">');
        child.append('<input type="hidden" name="action" value="edit">');
        child.append('<input type="hidden" name="index" value="' + edit_actions[i].index + '">');
        if (edit_actions[i].type === 'select') {
            child.append('<button type="button" class="selectbutton btn btn-pramary">Pick from cursor</button>');
        }
        child.append('<input type="submit" name="submit" class="editbutton btn btn-success" id="submit_btn" value="Edit" />');


        col.append(label, child);

        codeplayer_edit_form.append(col);
    }
    e.append(codeplayer_edit_form);

    selectButton(codeplayer);

    onclick_edit_button(codeplayer);

}

function select_options_input(arr_options, option, val) {
    var input = $('<select name="' + option + '"></select>');

    $.each(arr_options, function (key, value) {
        if (val === value) {
            input.append(
                $("<option></option>")
                    .attr("value", key)
                    .attr("selected", "selected")
                    .text(value)
            );
        } else {
            input.append(
                $("<option></option>")
                    .attr("value", key)
                    .text(value)
            );
        }
    });
    input.append('<br>');

    return input;
}

function text_input(option, value) {
    var input = $('<input type="text" name="' + option + '" value="' + value + '"><br>');
    return input;
}

function textarea_input(option, value) {
    return $('<textarea class="' + option + '" name="' + option + '" cols="40">' + JSON.stringify(value) + '</textarea><br>');
}

function hidden_input(option, value) {
    return $('<input type="hidden" name="' + option + '" value="' + value + '">');
}

function onclick_edit_button(codeplayer) {
    $('.error').hide();
    $(".editbutton").on('click', function () {
        var form = $(this).parents('form:first');
        var url = window.location.href;
        // var url = form.attr('action');

        $.ajax({
            type: 'POST',
            url: url,
            data: form.serialize(),
            success: function (data) {
                data = JSON.parse(data);
                if (!data.error) {
                    if (data.type === 'setStep') {
                        setStepAction(data, codeplayer);
                    }
                    else if (data.type === 'select') {
                        selectAction(data, codeplayer);
                    }
                    else if (data.type === 'popover') {
                        popoverAction(data, codeplayer);
                    }
                    else if (data.type === 'wait') {
                        waitAction(data, codeplayer);
                    }
                    else if (data.type === 'run') {
                        runAction(data, codeplayer);
                    }
                    else if (data.type === 'type') {
                        typeAction(data, codeplayer);
                    }
                    else if (data.type === 'readyAndCompile') {
                        readyAndCompileAction(data, codeplayer);
                    }
                }
                else {
                    alert('Error in edit_form js line 159');
                }
                console.log(data);
            },
            error: function (data) {
                alert('error');
            }
        });

        return false;
    });
}

function setStepAction(data, codeplayer) {
    codeplayer.actions[data.index].options.step = data.step;
    codeplayer.setStep(data.step);
}

function popoverAction(data, codeplayer) {
    if (data.text) {
        codeplayer.actions[data.index].options.text = data.text;
    }
    if (data.attachment) {
        codeplayer.actions[data.index].options.attachment = data.attachment;
    }
    if (data.locale) {
        codeplayer.actions[data.index].options.locale = data.locale;
    }
    if (data.selector) {
        codeplayer.actions[data.index].options.selector = data.selector;
    }
    if (data.placement) {
        codeplayer.actions[data.index].options.placement = data.placement;
    }
    codeplayer.next();
    codeplayer.back();
}

function selectAction(data, codeplayer) {
    if (data.text) {
        codeplayer.actions[data.index].options.text = data.text;
    }
    if (data.location) {
        codeplayer.actions[data.index].options.location = data.location;
    }

    alert('success save select');
}

function waitAction(data, codeplayer) {
    if (data.timeout) {
        codeplayer.actions[data.index].options.timeout = data.timeout;
    }
    codeplayer.back();
    codeplayer.next();
}

function runAction(data, codeplayer) {
    if (data.command) {
        codeplayer.actions[data.index].options.command = data.command;
    }
    codeplayer.back();
    codeplayer.next();
}

function typeAction(data, codeplayer) {
    if (data.text) {
        codeplayer.actions[data.index].options.text = data.text;
    }
    if (data.delay) {
        codeplayer.actions[data.index].options.delay = data.delay;
    }
    codeplayer.back();
    codeplayer.next();
}
function readyAndCompileAction(data, codeplayer) {
    if (data.text) {
        codeplayer.actions[data.index].options.text = data.text;
    }
    if (data.text2) {
        codeplayer.actions[data.index].options.text2 = data.text2;
    }
    if (data.locale) {
        codeplayer.actions[data.index].options.locale = data.locale;
    }
    if (data.success) {
        codeplayer.actions[data.index].options.success = data.success;
    }
    alert('success save readyAndCompile');
}

function selectButton(codeplayer) {
    $("button.selectbutton").on('click', function () {
        var form = $(this).parents('form:first');
        $('textarea.text').val(JSON.stringify(codeplayer.editor.getSelection()));
    });
}