function create_typing_protection(options, editor, player) {
    if (!options.edit_mode) {
        var $typing_shield = $('<div class="codeplayer-typing-shield"></div>');
        editor.display.wrapper.appendChild($typing_shield[0]);
        player.on('play resume', function() {
            $typing_shield.addClass('active');
            editor.getInputField().blur();
        });
        player.on('enable_edit_mode', function() {
            $typing_shield.removeClass('active');
        });
        player.on('disable_edit_mode', function() {
            $typing_shield.addClass('active');
        });
        player.on('stop', function() {
            $typing_shield.removeClass('active');
        });
        player.on('pause', function() {
            $typing_shield.removeClass('active');
        });
    }
}